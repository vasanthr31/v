const AuthService = require('./AuthService')
const FileService = require('./FileService')

module.exports = { AuthService, FileService }
