const fs = require('fs')
const os = require('os')
const path = require('path')

class FileService {
  #tempDir = path.join(os.tmpdir(), 'images')

  constructor () {
    if (!fs.existsSync(this.#tempDir)) {
      fs.mkdirSync(this.#tempDir, {
        recursive: true
      })
    }
  }

  createLocalFilePath = (fileName) => {
    return path.join(this.#tempDir, fileName)
  }

  getTempDirectory = () => {
    return this.#tempDir
  }

  static getInstance = () => {
    return new FileService()
  }
}

module.exports = FileService
