const ErrorHandler = require('./ErrorHandler')
const FileUploadHandler = require('./FileUploadHandler')

module.exports = { FileUploadHandler, ErrorHandler }
