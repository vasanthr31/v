const AppError = require('./AppError')

module.exports = { AppError }
