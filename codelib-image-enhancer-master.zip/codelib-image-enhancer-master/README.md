## Image Enhancer CodeLib Solution

The Image Enhancer CodeLib solution enables you to resize images to the required dimensions and compress them without distorting the image quality.

**Note:** You can get more detailed information on the steps to install and configure the Image Enhancer CodeLib solution from your Catalyst console. You must navigate to the bottom of your Catalyst console where you will find the ***Catalyst CodeLib*** section. You can click on the **Image Enhancer CodeLib** tile to access the steps.

### How does the CodeLib solution work?

Upon installing this CodeLib solution, pre-defined Catalyst components specific to the solution will be automatically configured in your project. This includes one [Catalyst Serverless function](https://docs.catalyst.zoho.com/en/serverless/help/functions/introduction/) ([Advanced I/O](https://docs.catalyst.zoho.com/en/serverless/help/functions/advanced-io/)) in **Node.js**. We will also be using the Catalyst SmartBrowz service in this CodeLib solution.

Upon the installation of the CodeLib solution, when you invoke the **_/resize_** endpoint of the **image_function**([Advanced I/O](https://docs.catalyst.zoho.com/en/serverless/help/functions/advanced-io/)) function as a _cURL_ request, the image is rendered and resized with the height and width provided in the request payload, using the [Canvas API](https://docs.catalyst.zoho.com) and placed in an html file. Along with the dimensions, you must also configure the original image path in the request payload. We will be using the Catalyst SmartBrowz service to connect to a headless chrome and take a screenshot of the html page served in the browser. We have implemented this using the puppeteer framework, the popular Node.js library used to control the headless browser using the pre-configured commands in Javascript. The screenshot will be provided as the API response in the _.png_ format.

You will also need to configure a key named **CODELIB_SECRET_KEY** as an [environmental variable ](https://docs.catalyst.zoho.com/en/serverless/help/functions/implementation/#environmental-variables) in the functions code, and pass this in the request header every time you try to access any endpoints of the pre-configured functions in the CodeLib solution. This key allows you to access the Catalyst resources of the CodeLib solution securely.

Similarly, when you invoke the **_/compress_** endpoint of the **image_function**([Advanced I/O](https://docs.catalyst.zoho.com/en/serverless/help/functions/advanced-io/)) function as a _cURL_ request by configuring the original image file path and level of compression required, the image will be compressed based on the inputs provided in the request payload in a html format.

You can define the compression level to any integer value ranging from 1 to 100. Again, similar to **_/resize_** API, we have used the Catalyst SmartBrowz service to take a screenshot and send its a response in the _.png_ format. Also note that, the configured maximum height and width dimensions of the input image is 2000\*2000 pixels.

**Note:**

- You can get more detailed information on the steps to install and configure the Image Enhancer CodeLib solution from the **_Catalyst CodeLib_** section in your Catalyst console.

### Resources Involved:

The following Catalyst resources are used as a part of the Image Enhancer CodeLib solution:

**1. [Catalyst Serverless Functions](https://docs.catalyst.zoho.com/en/serverless/help/functions/introduction/):**

This **image**([Advanced I/O](https://docs.catalyst.zoho.com/en/serverless/help/functions/advanced-io/))function handles the logic to resize and compress the input images and returns the resized or compressed response image in the _.png_ format.

**2. [Catalyst SmartBrowz](https://docs.catalyst.zoho.com/en/smartbrowz/getting-started/introduction/):**

We have used the Catalyst SmartBrowz service in this CodeLib solution to connect to a headless Chrome browser. The images modified using the Canvas API will be in the HTML format. We will input this html file to the Puppeteer framework in the SmartBrowz service. This will serve the HTML in a browser webpage and take a screenshot of the updated image, and return it in the ._png_ format.
